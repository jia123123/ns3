#include "ns3/node.h"
#include "ns3/packet.h"
#include "ns3/simulator.h"
#include "ns3/log.h"
#include "ns3/node-container.h"
#include "ns3/net-device-container.h"
#include "ns3/yans-wifi-helper.h"
#include "ns3/mobility-helper.h"
#include "ns3/rng-seed-manager.h"
#include "ns3/command-line.h"
#include "ns3/mobility-module.h"
#include "ns3/mobility-model.h"
#include <iostream>
#include <algorithm>
#include <cmath>
#include "ns3/string.h"
#include "ns3/double.h"
#include "ns3/object-map.h"
#include "ns3/regular-wifi-mac.h"
#include "ns3/constant-velocity-mobility-model.h"
#include "ns3/wave-net-device.h"
#include "ns3/wave-mac-helper.h"
#include "ns3/csma-module.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/applications-module.h"
#include "ns3/wifi-module.h"
#include "ns3/internet-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/wave-helper.h"
#include "ns3/netanim-module.h"
#include "ns3/inet-socket-address.h"
#include "ns3/application.h"
using namespace ns3;

NS_LOG_COMPONENT_DEFINE ("WaveMultipleChannelTest");//使用NS_LOG宏定义component
//SM阶段
class StatusTag : public Tag
{
public:
  StatusTag (void);
  StatusTag (uint32_t nodeid,Vector vec,double acce);
  void SetVelocity (const Vector &vec);//设置车辆位置信息
  Vector GetVelocity (void) const;//获取车辆位置信息
  double GetAcceleration(void);
  void SetAcceleration(double acce);
  void SetNodeId(uint32_t nodeId);//设置发送节点的id
  uint32_t GetNodeId(void) const;

  static TypeId GetTypeId (void);
  virtual TypeId GetInstanceTypeId (void) const;
  virtual uint32_t GetSerializedSize (void) const;
  virtual void Serialize (TagBuffer i) const;
  virtual void Deserialize (TagBuffer i);
  virtual void Print (std::ostream &os) const;

private:
  uint32_t m_nodeId;//车辆的节点id
  Vector m_vec; //车辆速度
  double accele;
};
StatusTag::StatusTag (void)
 {
 }
StatusTag::StatusTag (uint32_t nodeid,Vector vec,double acce)
  :m_nodeId(nodeid),m_vec(vec),accele(acce)
{
}
  //设置SeqTsHeader车辆位置信息,告诉接收节点发送节点的位置
  void
  StatusTag::SetVelocity(const Vector &vec)
  {
  	m_vec = vec;
  }
  //获取车辆位置信息
  Vector
  StatusTag::GetVelocity(void) const
  {
  	 return m_vec;
  }
  double
  StatusTag::GetAcceleration(void)
  {
	  return accele;
  }
   void
   StatusTag::SetAcceleration(double acce){
	   accele = acce;
   }
  void
  StatusTag::SetNodeId(uint32_t nodeId){
  	m_nodeId = nodeId;
  }
  uint32_t
  StatusTag::GetNodeId(void) const{
  	   return m_nodeId;
    }
TypeId
StatusTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::StatusTag")
    .SetParent<Tag> ()
    .AddConstructor<StatusTag> ()
  ;
  return tid;
}
TypeId
StatusTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
StatusTag::GetSerializedSize (void) const
{
  return  sizeof (uint32_t)+12 +8;
}
void
StatusTag::Serialize (TagBuffer i) const
{
  i.WriteU32 (m_nodeId);
  i.WriteU32(m_vec.x);
  i.WriteU32(m_vec.y);
  i.WriteU32(m_vec.z);
  i.WriteDouble(accele);

}
void
StatusTag::Deserialize (TagBuffer i)
{
  m_nodeId=i.ReadU32();
  m_vec.x=i.ReadU32();
  m_vec.y=i.ReadU32();
  m_vec.z=i.ReadU32();
  accele=i.ReadDouble();
}
void
StatusTag::Print (std::ostream &os) const
{
}
//chem阶段
class BusTag : public Tag
{
public:
	BusTag (void);
	BusTag (uint32_t seq,uint32_t nodeid,double mobility);
   double GetMobility(void);
   uint32_t GetNodeId(void);
   uint32_t GetSequence(void);

  static TypeId GetTypeId (void);
  virtual TypeId GetInstanceTypeId (void) const;
  virtual uint32_t GetSerializedSize (void) const;
  virtual void Serialize (TagBuffer i) const;
  virtual void Deserialize (TagBuffer i);
  virtual void Print (std::ostream &os) const;

private:
  uint32_t sequence;//标明属于创建阶段/维护阶段
  uint32_t m_nodeId;//车辆的节点id
  double mobisimi;


};

BusTag::BusTag (void)
 {
 }
BusTag::BusTag (uint32_t seq,uint32_t nodeid,double mobility)
  :sequence(seq),m_nodeId(nodeid),mobisimi(mobility)
{
}
  double
  BusTag::GetMobility(void)
  {
	  return mobisimi;
  }
  uint32_t
  BusTag::GetNodeId(void)
 {
  	   return m_nodeId;
    }
  uint32_t
  BusTag::GetSequence(void)
  {
	  return sequence;
  }
TypeId
BusTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BusTag")
    .SetParent<Tag> ()
    .AddConstructor<BusTag> ()
  ;
  return tid;
}
TypeId
BusTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
BusTag::GetSerializedSize (void) const
{
  return  sizeof(uint32_t)+sizeof (uint32_t)+8;
}
void
BusTag::Serialize (TagBuffer i) const
{
  i.WriteU32(sequence);
  i.WriteU32 (m_nodeId);
  i.WriteDouble(mobisimi);
}
void
BusTag::Deserialize (TagBuffer i)
{
  sequence=i.ReadU32();
  m_nodeId=i.ReadU32();
  mobisimi=i.ReadDouble();
}
void
BusTag::Print (std::ostream &os) const
{
}
//BM阶段
class HeaderTag:public Tag
{
public:
	HeaderTag(void);
	HeaderTag(uint32_t nodeid,Vector vec,Vector pos);
	uint32_t GetNodeId(void);
	Vector GetVelocity (void);
	Vector GetPosition(void);

	static TypeId GetTypeId (void);
	  virtual TypeId GetInstanceTypeId (void) const;
	  virtual uint32_t GetSerializedSize (void) const;
	  virtual void Serialize (TagBuffer i) const;
	  virtual void Deserialize (TagBuffer i);
	  virtual void Print (std::ostream &os) const;
private:
	uint32_t id;
	Vector velocity;
	Vector position;
};
HeaderTag::HeaderTag(void)
{

}
HeaderTag::HeaderTag(uint32_t nodeid,Vector vec,Vector pos)
:id(nodeid),velocity(vec),position(pos)
{

}
uint32_t
HeaderTag::GetNodeId(void)
{
	return id;
}
Vector
HeaderTag::GetVelocity (void)
{
	return velocity;
}
Vector
HeaderTag::GetPosition(void)
{
	return position;
}
TypeId
HeaderTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::HeaderTag")
    .SetParent<Tag> ()
    .AddConstructor<HeaderTag> ()
  ;
  return tid;
}
TypeId
HeaderTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
HeaderTag::GetSerializedSize (void) const
{
  return  sizeof (uint32_t)+12 + 12;
}
void
HeaderTag::Serialize (TagBuffer i) const
{
  i.WriteU32 (id);
  i.WriteU32(velocity.x);
  i.WriteU32(velocity.y);
  i.WriteU32(velocity.z);
  i.WriteU32(position.x);
  i.WriteU32(position.y);
  i.WriteU32(position.z);
}
void
HeaderTag::Deserialize (TagBuffer i)
{
  id=i.ReadU32();
  velocity.x=i.ReadU32();
  velocity.y=i.ReadU32();
  velocity.z=i.ReadU32();
  position.x=i.ReadU32();
  position.y=i.ReadU32();
  position.z=i.ReadU32();
}
void
HeaderTag::Print (std::ostream &os) const
{
}
//RM阶段，普通车辆向簇头发送入簇请求
class RequestTag : public Tag
{
public:
	RequestTag (void);
	RequestTag (uint32_t chid,uint32_t nodeid,Vector vec,double acce);
  void SetVelocity (const Vector &vec);
  Vector GetVelocity (void) const;
  double GetAcceleration(void);
  void SetAcceleration(double acce);
  void SetNodeId(uint32_t nodeId);//设置发送节点的id
  uint32_t GetNodeId(void) const;
  uint32_t GetCheadId(void);

  static TypeId GetTypeId (void);
  virtual TypeId GetInstanceTypeId (void) const;
  virtual uint32_t GetSerializedSize (void) const;
  virtual void Serialize (TagBuffer i) const;
  virtual void Deserialize (TagBuffer i);
  virtual void Print (std::ostream &os) const;

private:
  uint32_t chid;
  uint32_t m_nodeId;//车辆的节点id
  Vector m_vec; //车辆速度
  double accele;
};
RequestTag::RequestTag (void)
 {
 }
RequestTag::RequestTag (uint32_t chid,uint32_t nodeid,Vector vec,double acce)
  :chid(chid),m_nodeId(nodeid),m_vec(vec),accele(acce)
{
}
  //设置SeqTsHeader车辆位置信息,告诉接收节点发送节点的位置
  void
  RequestTag::SetVelocity(const Vector &vec)
  {
  	m_vec = vec;
  }
  //获取车辆位置信息
  Vector
  RequestTag::GetVelocity(void) const
  {
  	 return m_vec;
  }
  double
  RequestTag::GetAcceleration(void)
  {
	  return accele;
  }
   void
   RequestTag::SetAcceleration(double acce){
	   accele = acce;
   }
  void
  RequestTag::SetNodeId(uint32_t nodeId){
  	m_nodeId = nodeId;
  }
  uint32_t
  RequestTag::GetNodeId(void) const{
  	   return m_nodeId;
    }
  uint32_t
  RequestTag::GetCheadId(){
	  return chid;
  }
TypeId
RequestTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::RequestTag")
    .SetParent<Tag> ()
    .AddConstructor<RequestTag> ()
  ;
  return tid;
}
TypeId
RequestTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
RequestTag::GetSerializedSize (void) const
{
  return  sizeof (uint32_t)+sizeof (uint32_t)+12 +8;
}
void
RequestTag::Serialize (TagBuffer i) const
{
  i.WriteU32 (chid);
  i.WriteU32 (m_nodeId);
  i.WriteU32(m_vec.x);
  i.WriteU32(m_vec.y);
  i.WriteU32(m_vec.z);
  i.WriteDouble(accele);

}
void
RequestTag::Deserialize (TagBuffer i)
{
  chid=i.ReadU32();
  m_nodeId=i.ReadU32();
  m_vec.x=i.ReadU32();
  m_vec.y=i.ReadU32();
  m_vec.z=i.ReadU32();
  accele=i.ReadDouble();
}
void
RequestTag::Print (std::ostream &os) const
{
}
//SCH阶段
class SchTag:public Tag
{
public:
	SchTag(){}
	SchTag(uint32_t src,uint32_t slot,double send_time)
	{
		src_id = src;
		timeslot = slot;
		sendtime = send_time;
	}
	uint32_t GetSrcid()
	{
		return src_id;
	}
	uint32_t GetTimeSlot()
	{
		return timeslot;
	}
	double GetSendTime()
	{
		return sendtime;
	}
	static TypeId GetTypeId (void);
	virtual TypeId GetInstanceTypeId (void) const;
    virtual uint32_t GetSerializedSize (void) const;
	virtual void Serialize (TagBuffer i) const;
	virtual void Deserialize (TagBuffer i);
    virtual void Print (std::ostream &os) const;
private:
	uint32_t src_id;
	uint32_t timeslot;
	double sendtime;
};
TypeId
SchTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::SchTag")
    .SetParent<Tag> ()
    .AddConstructor<SchTag> ()
  ;
  return tid;
}
TypeId
SchTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
SchTag::GetSerializedSize (void) const
{
  return sizeof (uint32_t) +  sizeof (uint32_t)+8;
}
void
SchTag::Serialize (TagBuffer i) const
{
  i.WriteU32 (src_id);
  i.WriteU32 (timeslot);
  i.WriteDouble(sendtime);
}
void
SchTag::Deserialize (TagBuffer i)
{
  src_id = i.ReadU32();
  timeslot = i.ReadU32();
  sendtime = i.ReadDouble();
}
void
SchTag::Print (std::ostream &os) const
{
}
/**
 * 时隙分配表，AM阶段
 */
class SlotTableTag:public Tag
{
public:
	SlotTableTag(void)
{
}
    SlotTableTag(uint32_t cid,uint32_t size,std::vector<TimeMessage> slottable)
  {
	cluster_id=cid;
	m_size=size;
	slot=slottable;
  }
	virtual ~SlotTableTag (void)
  {
  }
std::vector<TimeMessage> GetslotTable() const
	{
		return slot;
	}
	uint32_t GetCluster()
	{
		return cluster_id;
	}
	uint32_t GetSize()
	{
		return m_size;
	}
	static TypeId GetTypeId (void);
	virtual TypeId GetInstanceTypeId (void) const;
	virtual uint32_t GetSerializedSize (void) const;
	virtual void Serialize (TagBuffer i) const;
    virtual void Deserialize (TagBuffer i);
	virtual void Print (std::ostream &os) const;
private:
	uint32_t cluster_id;
	uint32_t m_size;
	std::vector<TimeMessage> slot;
};

TypeId
SlotTableTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::SlotTableTag")
    .SetParent<Tag> ()
	.AddConstructor<SlotTableTag> ();
  return tid;
}
TypeId
SlotTableTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
SlotTableTag::GetSerializedSize (void) const
{
  return sizeof (uint32_t)*2+12*m_size;
}
void
SlotTableTag::Serialize (TagBuffer i) const
{
	 i.WriteU32 (cluster_id);
	 i.WriteU32 (m_size);
	 for(uint32_t slottable_index = 0;slottable_index < m_size;slottable_index++)
	 {
		 i.WriteU32 (slot[slottable_index].src_id);
		 i.WriteU32(slot[slottable_index].channel);
		 i.WriteU32 (slot[slottable_index].slot_number);
	 }
}
void
SlotTableTag::Deserialize (TagBuffer i)
{
	cluster_id=i.ReadU32();
	m_size=i.ReadU32();
	for(uint32_t index = 0;index < m_size;index ++)
	{
		uint32_t src = i.ReadU32 ();
		uint32_t channel=i.ReadU32();
		uint32_t time = i.ReadU32 ();
		TimeMessage ch = TimeMessage(src,channel,time);
	    slot.push_back(ch);
	}
}
void
SlotTableTag::Print (std::ostream &os) const
{
}
class ClusterTag:public Tag
{
public:
	ClusterTag(void);
	ClusterTag(uint32_t seq,uint32_t clusterid);
	uint32_t GetClusterid(void);
	static TypeId GetTypeId (void);
	  virtual TypeId GetInstanceTypeId (void) const;
	  virtual uint32_t GetSerializedSize (void) const;
	  virtual void Serialize (TagBuffer i) const;
	  virtual void Deserialize (TagBuffer i);
	  virtual void Print (std::ostream &os) const;
private:
    uint32_t seq;
	uint32_t clusterid;
};
ClusterTag::ClusterTag(void)
{
}
ClusterTag::ClusterTag(uint32_t rseq,uint32_t rclusterid)
:seq(rseq),clusterid(rclusterid)
{

}
uint32_t
ClusterTag::GetClusterid(void)
{
	return clusterid;
}

TypeId
ClusterTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::ClusterTag")
    .SetParent<Tag> ()
    .AddConstructor<ClusterTag> ()
  ;
  return tid;
}
TypeId
ClusterTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
ClusterTag::GetSerializedSize (void) const
{
  return  sizeof (uint32_t)+sizeof (uint32_t);
}
void
ClusterTag::Serialize (TagBuffer i) const
{
  i.WriteU32 (seq);
  i.WriteU32 (clusterid);
}
void
ClusterTag::Deserialize (TagBuffer i)
{
	seq=i.ReadU32();
  clusterid=i.ReadU32();
}
void
ClusterTag::Print (std::ostream &os) const
{
}
class RsuAckTag:public Tag
{
public:
	RsuAckTag(void);
	RsuAckTag(uint32_t rusnodeid);
	uint32_t GetRsunodeid(void) const;
	static TypeId GetTypeId (void);
	  virtual TypeId GetInstanceTypeId (void) const;
	  virtual uint32_t GetSerializedSize (void) const;
	  virtual void Serialize (TagBuffer i) const;
	  virtual void Deserialize (TagBuffer i);
	  virtual void Print (std::ostream &os) const;
private:
	uint32_t rsunodeid;
};
RsuAckTag::RsuAckTag(void)
{
}
RsuAckTag::RsuAckTag(uint32_t rrusnodeid)
:rsunodeid(rrusnodeid)
{
}
uint32_t
RsuAckTag::GetRsunodeid(void) const
{
	return rsunodeid;
}

TypeId
RsuAckTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::RsuAckTag")
    .SetParent<Tag> ()
    .AddConstructor<RsuAckTag> ()
  ;
  return tid;
}
TypeId
RsuAckTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
RsuAckTag::GetSerializedSize (void) const
{
  return  sizeof (uint32_t);
}
void
RsuAckTag::Serialize (TagBuffer i) const
{
  i.WriteU32 (rsunodeid);
}
void
RsuAckTag::Deserialize (TagBuffer i)
{
	rsunodeid = i.ReadU32();
}
void
RsuAckTag::Print (std::ostream &os) const
{
}
class BusAckTag:public Tag
{
public:
	  BusAckTag(void);
	  BusAckTag(uint32_t rusnodeid,uint32_t senderid);
	  uint32_t GetRsunodeid(void);
	  uint32_t GetSendernodeid(void);
	  static TypeId GetTypeId (void);
	  virtual TypeId GetInstanceTypeId (void) const;
	  virtual uint32_t GetSerializedSize (void) const;
	  virtual void Serialize (TagBuffer i) const;
	  virtual void Deserialize (TagBuffer i);
	  virtual void Print (std::ostream &os) const;
private:
	uint32_t rsunodeid;
	uint32_t sendernodeid;
};
BusAckTag::BusAckTag(void)
{
}
BusAckTag::BusAckTag(uint32_t rrusnodeid,uint32_t rsenderid)
:rsunodeid(rrusnodeid),sendernodeid(rsenderid)
{
}
uint32_t
BusAckTag::GetRsunodeid(void)
{
	return rsunodeid;
}
uint32_t
BusAckTag::GetSendernodeid(void)
{
	return sendernodeid;
}
TypeId
BusAckTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::BusAckTag")
    .SetParent<Tag> ()
    .AddConstructor<BusAckTag> ()
  ;
  return tid;
}
TypeId
BusAckTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
BusAckTag::GetSerializedSize (void) const
{
  return  sizeof (uint32_t)+sizeof (uint32_t);
}
void
BusAckTag::Serialize (TagBuffer i) const
{
  i.WriteU32 (rsunodeid);
  i.WriteU32 (sendernodeid);
}
void
BusAckTag::Deserialize (TagBuffer i)
{
	rsunodeid = i.ReadU32();
	sendernodeid = i.ReadU32();
}
void
BusAckTag::Print (std::ostream &os) const
{
}
class GeneralMsTag:public Tag                //传递簇宏观信息
{
public:
	  GeneralMsTag(void);
	  GeneralMsTag(uint32_t rnodeid,Vector rposition,double rvec);
	  uint32_t Getnodeid(void)const;
	  Vector Getposition(void)const;
	  double Getvec(void)const;
	  static TypeId GetTypeId (void);
	  virtual TypeId GetInstanceTypeId (void) const;
	  virtual uint32_t GetSerializedSize (void) const;
	  virtual void Serialize (TagBuffer i) const;
	  virtual void Deserialize (TagBuffer i);
	  virtual void Print (std::ostream &os) const;
private:
	uint32_t nodeid;
	Vector position;
	double vec;
};
GeneralMsTag::GeneralMsTag(void)
{
}
GeneralMsTag::GeneralMsTag(uint32_t rnodeid,Vector rposition,double rvec)
:nodeid(rnodeid),position(rposition),vec(rvec)
{
}
uint32_t
GeneralMsTag::Getnodeid(void)const
{
	return nodeid;
}
Vector
GeneralMsTag::Getposition(void)const
{
	return position;
}
double
GeneralMsTag::Getvec(void)const
{
	return vec;
}
TypeId
GeneralMsTag::GetTypeId (void)
{
  static TypeId tid = TypeId ("ns3::GeneralMsTag")
    .SetParent<Tag> ()
    .AddConstructor<GeneralMsTag> ()
  ;
  return tid;
}
TypeId
GeneralMsTag::GetInstanceTypeId (void) const
{
  return GetTypeId ();
}
uint32_t
GeneralMsTag::GetSerializedSize (void) const
{
  return  sizeof(uint32_t)+24+8;
}
void
GeneralMsTag::Serialize (TagBuffer i) const
{
  i.WriteU32(nodeid);
  i.WriteDouble(position.x);
  i.WriteDouble(position.y);
  i.WriteDouble(position.z);
  i.WriteDouble(vec);
}
void
GeneralMsTag::Deserialize (TagBuffer i)
{
	 nodeid = i.ReadU32();
	Vector rposition(i.ReadDouble(),i.ReadDouble(),i.ReadDouble());
	position=rposition;
	vec=i.ReadDouble();
}
void
GeneralMsTag::Print (std::ostream &os) const
{
}
//定义UDP应用
class MyApp : public Application
{
public:

  MyApp ();
  virtual ~MyApp();

  void Setup (Ptr<Node> node,Address raddress, Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate);

private:
  virtual void StartApplication (void);
  virtual void StopApplication (void);

  void ScheduleTx (void);
  void SendPacket ();
  void ReceivePacket (Ptr<Socket>);

  Ptr<Socket>     m_socket;
  Ptr<Socket>     m_rsocket;
  Address         m_peer;
  uint32_t        m_packetSize;
  uint32_t        m_nPackets;
  DataRate        m_dataRate;
  EventId         m_Event;
  bool            m_running;
  uint32_t        m_packetsReceived;
  uint32_t        m_packetsSent;
  Ptr<Packet>     m_spacket;
  Ptr<Packet>     m_rpacket;
  uint8_t*        rxPayload;
  Address         m_raddress;
  Ptr<Node>            node;
};

MyApp::MyApp ()
  : m_socket (0),
    m_peer (),
    m_packetSize (0),
    m_nPackets (0),
    m_dataRate (0),
    m_Event (),
    m_running (false),
    m_packetsSent (0)
{
}

MyApp::~MyApp()
{
  m_socket = 0;
}

void
MyApp::Setup (Ptr<Node> node,Address raddress ,Address address, uint32_t packetSize, uint32_t nPackets, DataRate dataRate)
{
  //m_socket = socket;
  this->node=node;
  m_peer = address;
  m_packetSize = packetSize;
  m_nPackets = nPackets;
  m_dataRate = dataRate;
  m_raddress=raddress;
  //Socket::CreateSocket (nodes.Get (0), UdpSocketFactory::GetTypeId ())
}

void
MyApp::StartApplication (void)
{
  m_socket = Socket::CreateSocket (node, UdpSocketFactory::GetTypeId ());
  m_running = true;
  m_packetsSent = 0;
  m_packetsReceived=0;
  m_socket->Bind ();

  Ptr<SocketFactory> sockFactory = node->GetObject<UdpSocketFactory> ();
  m_rsocket=sockFactory->CreateSocket ();
  m_rsocket->Bind (InetSocketAddress (Ipv4Address::GetAny (), 8085));             //接收地址为0.0.0.0

  m_rsocket->Connect (m_peer);
  m_socket->Connect (m_peer);
    m_socket->SetRecvCallback (MakeCallback(&MyApp::ReceivePacket,this));
     m_rsocket->SetRecvCallback (MakeCallback(&MyApp::ReceivePacket,this));
    SendPacket ();
}

void
MyApp::StopApplication (void)
{
  m_running = false;

  if (m_Event.IsRunning ())
    {
      Simulator::Cancel (m_Event);
    }

  if (m_socket)
    {
      m_socket->Close ();
    }
}
//发送大致
void
MyApp::SendPacket ()
{
  uint32_t senderid=node->GetId();
  Vector position=node->GetPosition();
  double vec=node->GetVelocity();
  GeneralMsTag generalmstag(senderid,position,vec);
 // GeneralMsTag gms;
 //  std::cout << senderid << "\t" << position << "\t" << vec << std::endl;
  Ptr<Packet> packet = Create<Packet>(500);
  packet->AddByteTag(generalmstag);
 // packet->FindFirstMatchingByteTag (gms);
 // std::cout << gms.Getnodeid();
  bool result=m_socket->Send (packet);
  if(!result)
	  std::cout << "send generalms failed" << std::endl;
  if (++m_packetsSent < m_nPackets)
    {
      ScheduleTx ();
    }
}

void
MyApp::ReceivePacket (Ptr<Socket> socket)
{
  //uint32_t availableData;
  //availableData = socket->GetRxAvailable ();
  ++m_packetsReceived;
  m_rpacket = socket->Recv (std::numeric_limits<uint32_t>::max (), 0);
  GeneralMsTag generalmstag;//每个节点广播自己的节点，健康值，位置
  bool result = m_rpacket->FindFirstMatchingByteTag (generalmstag);
  if(!result)
  {
	  std::cout << "receive general ms failed" << std::endl;
  }
std::cout << generalmstag.Getnodeid() << "\t" << generalmstag.Getvec() << std::endl;
}

void
MyApp::ScheduleTx (void)
{
  if (m_running)
    {
      Time tNext (Seconds (m_packetSize * 8 / static_cast<double> (m_dataRate.GetBitRate ())));
      m_Event = Simulator::Schedule (tNext, &MyApp::SendPacket, this);

    }
}

// it is useless here we can use any value we like
// because we only allow to send and receive one type packets
#define Packet_Number 0x8888

// the transmission range of a device should be decided carefully,
// since it will affect the packet delivery ratio
// we suggest users use wave-transmission-range.cc to get this value
#define Device_Transmission_Range 150

class MultipleChannelsExperiment
{
public:
  MultipleChannelsExperiment (void);
  bool Configure (int argc, char **argv);
  void Run (void);
  std::ofstream in;
private:
  void CreateNodes (void);
  void CreateWaveDevice (void);
  void CreateDevice (void);
  void SetupMobility (void);
  void InstallApplication (void);
  void SendSm (Ptr<WaveNetDevice> sender, uint32_t channelNumber);
  void SendChem (Ptr<WaveNetDevice> sender, uint32_t channelNumber,uint32_t number);
  void SendBm (Ptr<WaveNetDevice> sender, uint32_t channelNumber,uint32_t number);
  void SendRm (Ptr<WaveNetDevice> sender, uint32_t channelNumber);
  void SendAm (Ptr<WaveNetDevice> sender, uint32_t channelNumber);
  void SendSch(Ptr<WaveNetDevice> sender,uint32_t slot);
  void SendMainBm(Ptr<WaveNetDevice> sender, uint32_t channelNumber);
  void VehicleSendJoin(Ptr<WaveNetDevice> sender, uint32_t channelNumber,uint32_t headid);
  double GetBusValue(Ptr<Node> src);
  double CalculateMS(Vector vec,double acce,Vector des_vec,double des_accce);
  void Sendclustermessage(Ptr<WaveNetDevice> sender, uint32_t channelNumber);
  void Sendrusackmessage(Ptr<WaveNetDevice> sender, uint32_t channelNumber);
  void Sendbusackmessage(Ptr<WaveNetDevice> sender, uint32_t channelNumber);
  void Sendprobemessage(Ptr<WaveNetDevice> sender, uint32_t channelNumber);
  void Createudp();
  bool Receive (Ptr<NetDevice> dev, Ptr<const Packet> pkt, uint16_t mode, const Address &sender);
  void InitStatus (void);
  void Stats (uint32_t randomNumber);

  NodeContainer nodes,rsunodes,cloudnodes,twonodes,wifinodes,p2pnodes1,p2pnodes2,p2pnodes3,nodessum;
  NetDeviceContainer devices_wave,devices,rsudevices,p2pdevices1,p2pdevices2,p2pdevices3,csmaDevices,staDevices,apDevices,wifiDevices;
  Ipv4InterfaceContainer csmaInterfaces,p2p1Interfaces,p2p2Interfaces,p2p3Interfaces,wifiInterfaces;
  YansWifiPhyHelper phy;
  uint32_t nodesNum,cloudnodesNum,rsunodesNum;          // current nodes in 4-lines and 1km
  uint32_t freq;              // the frequency for sending packets
  uint32_t simulationTime;    // simulation time
  uint32_t size;              // the size of packet
  bool broadcast;
  Ptr<UniformRandomVariable> rng;//随机生成发送时间
  Ptr<UniformRandomVariable> random_velocity;//随机速度
   Ptr<UniformRandomVariable> random_acceleration;//随机加速度
   //Ptr<UniformRandomVariable> random_busid;//随机车辆为公交车

  // used for identifying received packet
  uint32_t sequence;
  uint32_t cluster_seq;
  // every received packets will be used for stat the duplicate packet
  // and duplicate packet case will only happen in unicast
  std::vector <uint32_t> receivedPackets;
  // we will check whether the packet is received by the neighbors in the transmission range
  std::map<uint32_t, std::vector<uint32_t> *> broadcastPackets;//uint32_t是节点ID, std::vector<uint32_t> 是节点的邻居
  class SendStat
  {
  public:
    uint32_t inCchi;
    uint32_t inCgi;
    uint32_t inSchi;
    uint32_t inSgi;
    SendStat (): inCchi (0), inCgi (0), inSchi (0), inSgi (0){}
  };
  SendStat sends;
  uint32_t receives;
  uint32_t queues;
  uint64_t delaySum;        // us
  uint64_t receiveSum;
  uint32_t run;
  double pdr,delay,system_throughput,average_throughput;
  uint32_t max_channel;//信道
  uint32_t cur_channel;//当前信道
  uint32_t max_timeslot;//时隙个数
  uint32_t send_number;
  uint32_t receive_number;
  double sumdelay;
  char filename[15];
  uint32_t sum_change_head;
};

MultipleChannelsExperiment::MultipleChannelsExperiment (void)
  : nodesNum (20),
	cloudnodesNum(10),
    rsunodesNum(2),
    freq (5),               // 10Hz, 100ms send one safety packet
    simulationTime (10),     // make it run 10s >=９秒时会出现Simulator::Now () - m_lastRxStart <= m_sifs
	size (150),             // packet size
    broadcast (true),
    sequence (0),
	cluster_seq(0),
    receives (0),
    queues (0),
    delaySum (0),
    receiveSum (0),
    run (1),
    pdr (0),
    delay (0),
    system_throughput (0),
    average_throughput (0),
	max_channel(3),
	cur_channel(0),
	max_timeslot(15),
	send_number(0),
	receive_number(0),
	sumdelay(0),
	filename("bus20.txt"),
	sum_change_head(0)
{
}

bool
MultipleChannelsExperiment::Configure (int argc, char **argv)
{
  CommandLine cmd;
  cmd.AddValue ("nodes", "Number of nodes.", nodesNum);
  cmd.AddValue ("time", "Simulation time, s.", simulationTime);
  cmd.AddValue ("size", "Size of safety packet, bytes.", size);
  cmd.AddValue ("frequency", "Frequency of sending safety packets, Hz.", freq);
  cmd.AddValue ("broadcast", "transmission mechanism:broadcast (true) or unicast (false), boolean).", broadcast);
  cmd.AddValue ("run", "to make the result more credible, make simulation run many times with different random number).", run);

  cmd.Parse (argc, argv);//将命令行输入的参数作为类CommandLine的参数进行分析
  return true;
}
void
	MultipleChannelsExperiment::CreateNodes ()
	{
		  NS_LOG_FUNCTION (this);//记录描述每个调用函数信息
		  NS_ASSERT (nodesNum != 0);
		  nodes = NodeContainer ();
		  nodes.Create (nodesNum);
		  rsunodes=NodeContainer();
		  rsunodes.Create(rsunodesNum);
		  twonodes = NodeContainer ();
		  twonodes.Add(nodes);
		  twonodes.Add(rsunodes);
		  cloudnodes=NodeContainer();
		  cloudnodes.Create(cloudnodesNum);
		  p2pnodes1.Add(rsunodes.Get(0));
		  p2pnodes1.Add(cloudnodes.Get(3));
		  p2pnodes2.Add(rsunodes.Get(1));
		  p2pnodes2.Add(cloudnodes.Get(7));
		  p2pnodes3.Add(rsunodes);
		  nodessum.Add(twonodes);
		  nodessum.Add(cloudnodes);
		  wifinodes.Add(nodes);
		  wifinodes.Add(cloudnodes);
	}

void
MultipleChannelsExperiment::CreateWaveDevice (void)
{
	      NS_LOG_FUNCTION (this);
		  // the transmission range is about 300m refer to "wave-transmission-range.cc"
		  YansWifiChannelHelper waveChannel;
		  waveChannel.SetPropagationDelay ("ns3::ConstantSpeedPropagationDelayModel");
		  waveChannel.AddPropagationLoss ("ns3::TwoRayGroundPropagationLossModel",
		 			  	  	  	  	  	  "Frequency", DoubleValue (5.89e9),
		 			  	  	  	  	      "HeightAboveZ", DoubleValue (0.5));
		  YansWifiPhyHelper wavePhy =  YansWifiPhyHelper::Default ();
		  //传输功率
		  wavePhy.Set("TxPowerStart",  DoubleValue (15));//最大为16.0206
		  wavePhy.Set("TxPowerEnd",  DoubleValue (15));
		  //传输范围:250m
		  wavePhy.SetChannel (waveChannel.Create ());
		  QosWaveMacHelper waveMac = QosWaveMacHelper::Default ();
		  WaveHelper waveHelper = WaveHelper::Default ();
		  devices = waveHelper.Install (wavePhy, waveMac, nodes);
		  rsudevices= waveHelper.Install (wavePhy, waveMac, rsunodes);
	//	  devices_wave = waveHelper.Install (wavePhy, waveMac, twonodes);
		  devices_wave.Add(devices);
		  devices_wave.Add(rsudevices);
		  for (uint32_t i = 0; i != devices_wave.GetN (); ++i)
		    {
			  std::cout << i;
			  Ptr<WaveNetDevice> device = DynamicCast<WaveNetDevice> (devices_wave.Get (i));
      	      device->SetReceiveCallback (MakeCallback (&MultipleChannelsExperiment::Receive,this));
		    }
}
void
MultipleChannelsExperiment::CreateDevice (void)
{
	   PointToPointHelper pointToPoint;
	   pointToPoint.SetDeviceAttribute ("DataRate", StringValue ("5Mbps"));
	   pointToPoint.SetChannelAttribute ("Delay", StringValue ("2ms"));
	   p2pdevices1 = pointToPoint.Install (p2pnodes1);
	   p2pdevices2 = pointToPoint.Install (p2pnodes2);
	   p2pdevices3 = pointToPoint.Install (p2pnodes3);
	   CsmaHelper csma;
	   csma.SetChannelAttribute ("DataRate", StringValue ("100Mbps"));
	   csma.SetChannelAttribute ("Delay", TimeValue (NanoSeconds (6560)));
	   csmaDevices = csma.Install (cloudnodes);
	   YansWifiChannelHelper channel = YansWifiChannelHelper::Default ();
	   phy = YansWifiPhyHelper::Default ();
	   phy.SetChannel (channel.Create ());
	   WifiHelper wifi;
	   wifi.SetRemoteStationManager ("ns3::AarfWifiManager");
	   WifiMacHelper mac;
	   Ssid ssid = Ssid ("ns-3-ssid");
	   mac.SetType ("ns3::StaWifiMac",
	                   "Ssid", SsidValue (ssid),
	                   "ActiveProbing", BooleanValue (false));

	   staDevices = wifi.Install (phy, mac, nodes);
	   mac.SetType ("ns3::ApWifiMac",
	                   "Ssid", SsidValue (ssid));
	   apDevices = wifi.Install (phy, mac, cloudnodes);
	   InternetStackHelper stack;
	   stack.Install (cloudnodes);
	   stack.Install (p2pnodes3);
	   stack.Install (nodes);
	   Ipv4AddressHelper address;
	   Ipv4GlobalRoutingHelper::PopulateRoutingTables ();
       address.SetBase ("10.1.1.0", "255.255.255.0");
	   csmaInterfaces = address.Assign (csmaDevices);
	   address.SetBase ("10.1.2.0", "255.255.255.0");
	   p2p1Interfaces = address.Assign (p2pdevices1);
	   address.SetBase ("10.1.3.0", "255.255.255.0");
	   p2p2Interfaces = address.Assign (p2pdevices2);
	   address.SetBase ("10.1.4.0", "255.255.255.0");
	   p2p3Interfaces = address.Assign (p2pdevices3);
	   address.SetBase ("10.1.5.0", "255.255.255.0");
	   wifiDevices.Add(staDevices);
	   wifiDevices.Add(apDevices);
	   wifiInterfaces=address.Assign (wifiDevices);
}
void
MultipleChannelsExperiment::SetupMobility ()
{
	MobilityHelper mobility1,mobility2,mobility3;
		  // every node is in 1km * 4line. It is 3 meter between neighboring lines.
		  mobility1.SetPositionAllocator ("ns3::GridPositionAllocator",
		 		  	  	  	  	  	  	 "MinX", DoubleValue (0.0),
		 		  	  	  	  	  	  	 "MinY", DoubleValue (0.0),
		 		  	  	  	  	  	  	 "DeltaX", DoubleValue (0),
		 		  	  	  	  	  	  	 "DeltaY", DoubleValue (2),
		 		  	  	  	  	  	  	 "GridWidth", UintegerValue (10),
		 		  	  	  	  	  	  	 "LayoutType", StringValue ("RowFirst"));
		      mobility1.SetMobilityModel ("ns3::ConstantAccelerationMobilityModel");
		      mobility1.Install (nodes);
		      mobility2.SetPositionAllocator ("ns3::GridPositionAllocator",
		       		  	  	  	  	  	  	 "MinX", DoubleValue (300),
		       		  	  	  	  	  	  	 "MinY", DoubleValue (52.0),
		       		  	  	  	  	  	  	 "DeltaX", DoubleValue (400),
		       		  	  	  	  	  	  	 "DeltaY", DoubleValue (5),
		       		  	  	  	  	  	  	 "GridWidth", UintegerValue (2),
		       		  	  	  	  	  	  	 "LayoutType", StringValue ("RowFirst"));
		      mobility2.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
		      mobility2.Install (rsunodes);
		      mobility3.SetPositionAllocator ("ns3::GridPositionAllocator",
		       		  	  	  	  	  	  	 "MinX", DoubleValue (0.0),
		       		  	  	  	  	  	  	 "MinY", DoubleValue (102.0),
		       		  	  	  	  	  	  	 "DeltaX", DoubleValue (100),
		       		  	  	  	  	  	  	 "DeltaY", DoubleValue (5),
		       		  	  	  	  	  	  	 "GridWidth", UintegerValue (10),
		       		  	  	  	  	  	  	 "LayoutType", StringValue ("RowFirst"));
		      mobility3.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
		      mobility3.Install (cloudnodes);
		         double vec;
		         double acce;
		         random_velocity = CreateObject<UniformRandomVariable> ();
		         random_velocity->SetStream (1);
		         random_acceleration = CreateObject<UniformRandomVariable> ();
		         random_acceleration->SetStream (1);
		         for (NodeContainer::Iterator i = nodes.Begin (); i != nodes.End (); ++i)
		         {
		     	   Ptr<Node> node = (*i);
		     	    uint32_t nodeid = node->GetId();
		     	   vec = random_velocity->GetValue(30,60);
		     	   acce = random_acceleration->GetValue(0, vec*0.1);
		     	   Ptr<MobilityModel> model = node->GetObject<MobilityModel> ();
		     	   Vector pos = model->GetPosition ();
		     	   node->SetAcceleration(acce);//设置车辆的加速度
		     	   node->SetVelocity(vec);    //设置车辆速度
		     	   node->SetPosition(pos);
		            node->GetObject<ConstantAccelerationMobilityModel>()->SetVelocityAndAcceleration (Vector (vec,0,0),Vector(acce,0,0));
		            if((nodeid==0)|(nodeid==5))               //设置id号为0,13,23的车辆为公交车,但并不是簇头
		                  {
		               	   node->SetBusFlag(true);
		               	   node->SetRsuFlag(false);
		               	   node->SetClusterHeader(false);
		               	   node->SetClusterMemberFlag(false);
		                  }
		                  else{
		                   node->SetRsuFlag(false);
		               	   node->SetBusFlag(false);
		               	   node->SetClusterHeader(false);
		               	   node->SetClusterMemberFlag(false);
		                  }
		         }
		         for (NodeContainer::Iterator i = rsunodes.Begin (); i != rsunodes.End (); ++i)
		         {
		        	 Ptr<Node> node = (*i);
		        	 node->SetRsuFlag(true);
		        	 node->SetBusFlag(false);
		        	 node->SetClusterHeader(false);
		        	 node->SetClusterMemberFlag(false);
		         }
	/*	         for(NodeContainer::Iterator i = twonodes.Begin (); i != twonodes.End (); ++i)
		         {
		        	 Ptr<Node> node = (*i);
		        	 if(node->GetBusFlag())
		        		 std::cout << "node id : " << node->GetId() << " is a bus" << std::endl;
		        	 else if(node->GetRsuFlag())
		        		 std::cout << "node id : " << node->GetId() << " is a rsu" << std::endl;
		        	 else
		        		 std::cout << "node id : " << node->GetId() << " is a normal vehicle" << std::endl;
		         }    */
}

bool
MultipleChannelsExperiment::Receive (Ptr<NetDevice> dev, Ptr<const Packet> pkt, uint16_t mode, const Address &sender)
{
  NS_LOG_FUNCTION (this << dev << pkt << mode << sender);
  NS_ASSERT  (mode == Packet_Number);
  StatusTag tag;//每个节点广播自己的节点，健康值，位置
  bool result = pkt->FindFirstMatchingByteTag (tag);
  BusTag bus_tag;//公交车广播自己的移动相似性值
  bool bustag_result = pkt->FindFirstMatchingByteTag (bus_tag);
  HeaderTag header_tag;//簇头广播位置，速度
  bool headertag_result=pkt->FindFirstMatchingByteTag (header_tag);
  RequestTag reqtag;//普通车向簇头发送入簇请求，包括簇头id，自身id，速度，加速度
  bool reqtag_result=pkt->FindFirstMatchingByteTag(reqtag);
  SlotTableTag slottag;//簇头向簇成员广播信道分配表
  bool slot_result = pkt->FindFirstMatchingByteTag(slottag);
  SchTag schtag;
  bool sch_result = pkt->FindFirstMatchingByteTag(schtag);
  ClusterTag clustertag;
  bool cluster_result=pkt->FindFirstMatchingByteTag(clustertag);
  RsuAckTag rsuacktag;
  bool rsu_result=pkt->FindFirstMatchingByteTag(rsuacktag);
  BusAckTag busacktag;
  bool bus_result=pkt->FindFirstMatchingByteTag(busacktag);
  Ptr<Node> node=dev->GetNode();
  Ptr<WaveNetDevice> receiver= DynamicCast<WaveNetDevice> (dev->GetNode()->GetDevice(0));
  if(result)
  {

	  if(node->GetBusFlag())
	  {

		  uint32_t src_id=tag.GetNodeId();
		  Vector src_vec=tag.GetVelocity();
		  double src_acce = tag.GetAcceleration();
		  const StatusMessage sm=StatusMessage(src_id,src_vec,src_acce);
		  node->SetStatusMessage(sm);
	  }
  }
  else if(bustag_result)
  {
      if(node->GetBusFlag())
    	 {
    		 uint32_t other_bus=bus_tag.GetNodeId();
			 double other_simi=bus_tag.GetMobility();
			 BusMS cur=BusMS(other_bus,other_simi);
			 node->SetBusMS(cur);
    	 }
  }
  else if(headertag_result)
  {
    if(!node->GetClusterHeader())   //包含bus的非簇头
    {
      uint32_t headerid=header_tag.GetNodeId();
      Vector header_velocity=header_tag.GetVelocity();
      Vector header_pos=header_tag.GetPosition();
      HeaderMs cur=HeaderMs(headerid,header_velocity,header_pos);
      node->SetHeaderMessage(cur);
    }
  }
  else if(reqtag_result)//公交车&簇头收到后，保存下来，以备后面簇头计算通信顺序使用
  {
     if(node->GetClusterHeader())
     {
    	 uint32_t srcid=reqtag.GetNodeId();
    	 Vector velocity=reqtag.GetVelocity();
    	 double acce=reqtag.GetAcceleration();
 //   	 std::cout << srcid << "\t" << velocity << std::endl;
    	 StatusMessage sm=StatusMessage(srcid,velocity,acce);
    	 node->SetStatusMessage(sm);
     }
  }
  else if(slot_result)//簇成员接收簇头发送的时隙分配表
  {
	  if(node->GetClusterMemberFlag())
	  {
		  uint32_t headid=slottag.GetCluster();
		  if(headid == node->GetClusterId())
		  {
			  node->RemoveTime();
			  std::vector<TimeMessage> slottable = slottag.GetslotTable();
			  node->SetTimeMessage(slottable);
	//		  std::cout << "header: "<< headid << "  mumber: " <<node->GetId()<< std::endl;
		  }
	  }
  }
  else if(sch_result)//只计算簇内收到的
  {
	  double receivetime = Now().GetSeconds();
	   if(node->GetClusterMemberFlag())
	   {
		   uint32_t id=schtag.GetSrcid();
		   std::vector<TimeMessage> slot=node->GetTimeMessage();
		   std::vector<TimeMessage>::iterator i=std::find(slot.begin(),slot.end(),id);
		 if(i!=slot.end())
		 {
			  double sendtime = schtag.GetSendTime();
			   ++receive_number;
			  sumdelay += (receivetime - sendtime);
		 }
	   }
  }
  else if(cluster_result)
  {
  	if(node->GetRsuFlag())
  	{
        node->ClearRelateBus();
        uint32_t clusterid=clustertag.GetClusterid();
        ClusterMs clusterms(clusterid,sender);
        node->SetClusterMessage(clusterms);
  	}
  }
  else if(rsu_result)
  {

	  if((node->GetClusterHeader())&&(!node->GetRelateRsuFlag()))   //没有进行RSU关联的簇头
	  {
		  node->SetRelateRsuFlag(true);
		  uint32_t rsuid=rsuacktag.GetRsunodeid();
//		  std::cout << "bus received rsuid: " << rsuid << std::endl;  //测试bus接收到的rsu id值
		  node->SetRsuId(rsuid);
     }
  }
  else if(bus_result)
  {
	  uint32_t rsuid=busacktag.GetRsunodeid();
	  if(rsuid==node->GetId())
	  {
		  std::cout << "r";
		uint32_t busid=busacktag.GetSendernodeid();
		node->SetRelateBus(busid);
		node->ClearClusterMessage();
		std::cout << "rsuid: "<<node->GetId()<<" relate bus: "<<busid << std::endl;    //测试RSU记录的与哪个bus相关联
	  }
  }
	   return true;
	 }

//所有车辆节点广播自身信息
void
MultipleChannelsExperiment::SendSm (Ptr<WaveNetDevice> sender, uint32_t channelNumber)
{
  NS_LOG_FUNCTION (this << sender << channelNumber);
  Ptr<Packet> packet = Create<Packet> (size);
  Ptr<Node> src=sender->GetNode();
  src->RemoveStatusM();
  src->RemoveTime();
  if(!src->GetBusFlag())
  {
	    uint32_t src_nodeId=src->GetId();
	    Ptr<MobilityModel> model_src = src->GetObject<MobilityModel> ();
	    Vector veh_vec=model_src->GetVelocity();//获取速度
	    double acce = src->GetAcceleration();//获取加速度
	    StatusTag tag = StatusTag (src_nodeId,veh_vec,acce);
	    packet->AddByteTag (tag);
	    TxInfo info = TxInfo (channelNumber);
	    Mac48Address dest = Mac48Address::GetBroadcast ();
	    NodeContainer::Iterator i ;
	   sender->SendX (packet, dest, Packet_Number, info);
  }
}
/*
 * 计算公交车的移动相似性值
 */
double
MultipleChannelsExperiment::GetBusValue(Ptr<Node> src)
{
	    	Ptr<MobilityModel> model_src = src->GetObject<MobilityModel> ();
	    	Vector bus_vec=model_src->GetVelocity();
	    	double bus_acce=src->GetAcceleration();
	    	std::vector<StatusMessage> fromvec=src->GetStatusMessage();//获取公交车搜集到的普通车辆信息或簇成员信息
	    	double sum=0.0;
	    	 for(uint32_t i=0;i < fromvec.size();i++)
			{
	    		Vector veh_vec=fromvec[i].velocity;
				double veh_acce=fromvec[i].accele;
				sum+=CalculateMS(bus_vec,bus_acce,veh_vec,veh_acce);
	         }
	    	   double simi_value=sum/fromvec.size();
	    	   return simi_value;
}
/*
 * 创建阶段2：公交车计算自己的移动相似性后，将值广播出去
 * 维护阶段1：簇头节点根据簇成员计算自己的移动相似性值，然后广播id,移动相似性值，公交车则广播
 */
void
MultipleChannelsExperiment::SendChem(Ptr<WaveNetDevice> sender, uint32_t channelNumber,uint32_t number)
{
	 Ptr<Node> src=sender->GetNode();
	 uint32_t bus_id=src->GetId();
	 if(src->GetBusFlag())
	 {
		double simi_value=GetBusValue(src);//计算公交车的移动相似性值
		BusMS busms=BusMS(bus_id,simi_value);
		src->SetBusMS(busms);
		Ptr<Packet> packet = Create<Packet> (size);
		BusTag bustag=BusTag(number,bus_id,simi_value);
		packet->AddByteTag(bustag);
		TxInfo info = TxInfo (channelNumber);
		Address bsdest = Mac48Address::GetBroadcast ();
		sender->SendX(packet, bsdest, Packet_Number, info);
	 }
	 }
/**
 * 将收到的公交车信息按照降序排列
 */
bool GreaterBusSort(BusMS rm1,BusMS rm2)
   {
       return (rm1.mobility > rm2.mobility);
   }
/*
 * 创建阶段：公交车根据接收到的公交车移动相似性值，确定簇头；然后簇头广播自身信息
 * 维护阶段：簇头若是接收到的其他簇头移动值，比较后确定簇头；若是没有接收到，则不做任何操作
 */
void
MultipleChannelsExperiment::SendBm(Ptr<WaveNetDevice> sender, uint32_t channelNumber,uint32_t number)
{
  Ptr<Node> src=sender->GetNode();
  uint32_t srcid=src->GetId();
	  if(src->GetBusFlag())
	   {
	       std::vector<BusMS> simi_info=src->GetBusMS();
	       src->RemoveBusMS();
	       uint32_t size=simi_info.size();
	       std::sort(simi_info.begin(),simi_info.end(),GreaterBusSort);
	       uint32_t maxid=simi_info[0].nodeid;
	        if(srcid==maxid)
	        {
	     	   src->SetClusterHeader(true);
	     	   src->RemoveStatusM();//清空普通车辆信息或簇成员信息
	     	   Ptr<MobilityModel> model_src = src->GetObject<MobilityModel> ();
	     	   Vector header_vec=model_src->GetVelocity();
	     	   Vector header_pos=model_src->GetPosition();
	     	   Ptr<Packet> packet = Create<Packet> (size);
	           HeaderTag tag=HeaderTag(srcid,header_vec,header_pos);
	           packet->AddByteTag(tag);
	 		   TxInfo info = TxInfo (channelNumber);
	 		   Address bsdest = Mac48Address::GetBroadcast ();
	 		   sender->SendX(packet, bsdest, Packet_Number, info);
	        }
	        else
	        {
	     	   src->SetClusterHeader(false);
	        }
      }
}
/*
 *普通车辆入簇规则
 */
HeaderMs GetHead(Ptr<Node> src,std::vector<HeaderMs> heads)
{
	std::vector<HeaderMs>::iterator i;
	Ptr<MobilityModel> model_src = src->GetObject<MobilityModel> ();
	Vector src_pos=model_src->GetPosition();
	Vector src_velocity=model_src->GetVelocity();
	double mina=500;
	HeaderMs a,b;
	for(i=heads.begin();i!=heads.end();i++)//找到距离车辆同方向最近的两辆公交车簇头
	{
	  Vector cur=(*i).position;
	  double dis=fabs(src_pos.x-cur.x);
	  b=*i;
	  if(dis<mina)
	  {
		  mina=dis;
		  b=a;
		  a=(*i);
	  }
	}
//	std::cout << "a: "<<a.id << "\t" << "b: "<<b.id<<std::endl;
	double speed_a=src_velocity.x-a.velocity.x;
	double speed_b=src_velocity.x-b.velocity.x;
	double sa=fabs(src_velocity.x-a.velocity.x);
	double sb=fabs(src_velocity.x-b.velocity.x);
	double disa=src_pos.x-a.position.x;
	double disb=src_pos.x-b.position.x;
	HeaderMs head;
	if((speed_a>0) & (speed_b>0))
	{
		if(disa<disb)
		  head=a;
		else
		  head=b;
	}
	else if((speed_a<0) &(speed_b<0))
	{
		if(disa>disb)
		   head=a;
		else
		   head=a;
	}
	else if((speed_a>0) & (disa <0) & (speed_b <0) & (disb >0) )
	{
        if(sa>=sb)
		   head=a;
        else
        	head=b;
	}
	else if((speed_b>0) & (disb <0) & (speed_a <0) & (disa >0) )
		{
	        if(sa>=sb)
			   head=a;
	        else
	        	head=b;
		}
	else if((speed_a<0) & (disa <0) & (speed_b >0) & (disb >0))
	{
		if(sa<=sb)
		  head=a;
		else
		  head=b;
	}
	else if((speed_b<0) & (disb <0) & (speed_a >0) & (disa >0))
		{
			if(sa<=sb)
			  head=a;
			else
			  head=b;
		}
	else if((disa>0) & (disb>0))
		{
			if(sa>sb)
				head=a;
			else
				head=b;
		}
		else if((disa<0) & (disb<0))
		{
			if(sa<sb)
				head=a;
			else
				head=b;
		}

	return head;
}
/*
 * 车辆向簇头发送请求加入信息
 */
void
MultipleChannelsExperiment::VehicleSendJoin(Ptr<WaveNetDevice> sender, uint32_t channelNumber,uint32_t headid)
{
	 Ptr<Node> src=sender->GetNode();
	 uint32_t nodeid=src->GetId();
//	 Ptr<Node> des_node = nodes.Get(headid);
	// Address dest = des_node->GetDevice(1)->GetAddress();
	 Address dest = Mac48Address::GetBroadcast ();
	 Ptr<MobilityModel> model_src = src->GetObject<MobilityModel> ();
	 Vector velocity=model_src->GetVelocity();//获取速度
	 double acce = src->GetAcceleration();//获取加速度
	 Ptr<Packet> packet = Create<Packet> (size);
	 RequestTag tag=RequestTag(headid,nodeid,velocity,acce);
	 packet->AddByteTag(tag);
	 TxInfo info = TxInfo (channelNumber);
	 bool res=sender->SendX (packet, dest, Packet_Number, info);
	if(res)
	{
		src->SetClusterMemberFlag(true);//设置车辆是否入簇并且是入的哪一个簇头
		uint32_t old_id=src->GetClusterId();
		if(old_id!=headid)
		{
          ++sum_change_head;
		}
		src->SetClusterId(headid);//设置普通车辆的所属簇头节点
	}
}
/*
 * 创建阶段：普通车根据入簇规则，选择簇，向簇头发送请求加入信息
 * 维护阶段：簇成员车辆向原簇头发送应答信息；普通车辆按照入簇规则加入簇
 */
void
MultipleChannelsExperiment::SendRm(Ptr<WaveNetDevice> sender, uint32_t channelNumber)
{
	Ptr<Node> src=sender->GetNode();
	if(!src->GetClusterHeader())
	{
      std::vector<HeaderMs> heads=src->GetHeaderMessage();
      std::vector<HeaderMs>::iterator i;
 /*     for(i=heads.begin();i!=heads.end();i++)    //测试节点保存的簇头id有哪些
      {
    	  std::cout << "id: " << i->id <<"\t";
      }  */
      src->RemoveHeaderMs();
      uint32_t size=heads.size();
      if(size==1)
		{
			uint32_t headid=heads[0].id;
			VehicleSendJoin(sender,channelNumber,headid);
		}
		else if(size>1)
		{
			 HeaderMs head=GetHead(src,heads);
			 uint32_t headid=head.id;
	//		 std::cout << "when header number more than 2 header id is: " << headid <<std::endl;
			 VehicleSendJoin(sender,channelNumber,headid);
		}
		else if(size == 0)
		{
			src->SetClusterMemberFlag(false);
			++sum_change_head;
			src->SetClusterId(60);//设置普通车辆的所属簇头节点
		}
      }
}
/**
 * 将公交车移动相似值按照升序排列,越相似，分配的时隙越往后
 */
bool GreaterSort(StatusMessage sm1,StatusMessage sm2)
   {
       return (sm1.mobility_similarity < sm2.mobility_similarity);
   }
/*
 * 计算普通车辆的移动相似性值
 */
double
MultipleChannelsExperiment::CalculateMS(Vector vec,double acce,Vector des_vec,double des_acce)
{
	//double fabs(double x) 返回双精度参数x的绝对值
	//double exp(double x) 返回指数函数ex的值
	double vecms= exp(-fabs(vec.x-des_vec.x));
	double accems=exp(-fabs(acce-des_acce));
	return vecms*accems;
}
/*
 * 簇头搜到普通车辆的速度，加速度后，计算移动相似性值，形成时隙，信道表，然后广播出去，普通车辆收
 */
void
MultipleChannelsExperiment::SendAm (Ptr<WaveNetDevice> sender, uint32_t channelNumber)
{
	  Ptr<Node> src=sender->GetNode();
	  if(src->GetClusterHeader())
	  {
		uint32_t nodeid=src->GetId();
        std::vector<StatusMessage> neighbor_info = src->GetStatusMessage();
 //       src->RemoveStatusM();
        std::vector<StatusMessage>::iterator statu;
        uint32_t infosize=neighbor_info.size();
        //计算节点的平均移动相似性值
        for(uint32_t indexf=0;indexf < infosize;indexf++)
        {
        	uint32_t src_id=neighbor_info[indexf].nodeid;
			Vector vec=neighbor_info[indexf].velocity;
			double acce=neighbor_info[indexf].accele;
			double mobility_similarity=0.0;
        	for(uint32_t indexs=0;indexs < infosize;indexs++)
        	{
        		uint32_t des_id=neighbor_info[indexs].nodeid;
			    Vector des_vec=neighbor_info[indexs].velocity;
			    double des_acce=neighbor_info[indexs].accele;
				 if(src_id != des_id)
				 {
					mobility_similarity+=CalculateMS(vec,acce,des_vec,des_acce);
				 }
			 }
        	double avg=mobility_similarity/(infosize-1);
        	statu=std::find(neighbor_info.begin(),neighbor_info.end(),src_id);
        	StatusMessage curs=StatusMessage(src_id,vec,acce,avg);
        	src->SetStatusMessage(curs);
        }
        //测试得到的移动相似性
	  std::vector<StatusMessage> nei_info = src->GetStatusMessage();
      std::sort(nei_info.begin(),nei_info.end(),GreaterSort);//将邻居表按照移动相似性的大小升序排列
	  src->RemoveTime();
	  uint32_t ch= ++cur_channel;
	  for(uint32_t i=0;i<nei_info.size();++i)
	  {
		  TimeMessage slot= TimeMessage(nei_info[i].nodeid,ch,i+1);
		  src->SetTimeMessage(slot);
	  }
	  if(cur_channel == 1)
	 		cur_channel=0;
	/**
	* 簇头通过广播向簇成员发送时隙表
	*/
	  Ptr<Packet> packet = Create<Packet> (size);
	  std::vector<TimeMessage> slottable = src->GetTimeMessage();
	  SlotTableTag slot_table = SlotTableTag(nodeid,slottable.size(),slottable);
	  packet->AddByteTag(slot_table);
	  TxInfo info = TxInfo (channelNumber);
	  Address bsdest = Mac48Address::GetBroadcast ();
	 sender->SendX(packet, bsdest, Packet_Number, info);
	}
 }
/*
 * 普通车辆收到信息分配表后，按照信道和时隙进行传输
 */
void
MultipleChannelsExperiment::SendSch(Ptr<WaveNetDevice> sender,uint32_t slot)
{
	    Ptr<Node> node = sender->GetNode();
		uint32_t nodeid = node->GetId();
		if(!node->GetRsuFlag())
		{
		std::vector<TimeMessage> slottable = node->GetTimeMessage();
		uint32_t number=slottable.size();
		std::vector<TimeMessage>::iterator index;
		TimeMessage record=TimeMessage(nodeid,slot+1);
		index = std::find(slottable.begin(),slottable.end(),record);
		if(index != slottable.end())
		{
			Ptr<Packet> pkt = Create<Packet>(size);
			double now = Now ().GetSeconds();
			SchTag schtag = SchTag(nodeid,slot,now);
			pkt->AddByteTag(schtag);
			SchInfo schInfo = SchInfo (SCH1, true, EXTENDED_ALTERNATING);
			 TxInfo info = TxInfo (SCH1);
			 bool result;
			 Address broadcast = Mac48Address::GetBroadcast ();
			 result = sender->SendX(pkt, broadcast, Packet_Number, info);
			 if(result)
			 {
				 send_number=send_number+(number-1) ;
				  std::cout<<"sch send:src= "<< nodeid<<" slot= "<<slot<<",channel= 1"<<std::endl;
			 }

		}
	}
}
//簇头发送簇探测帧，检测周围是否有RSU的存在
void
MultipleChannelsExperiment::Sendprobemessage (Ptr<WaveNetDevice> sender, uint32_t channelNumber)
{
	Ptr<Node> node = sender->GetNode();
	if((node->GetClusterHeader())&&node->GetRelateRsuFlag())                            //如果为未关联rsu的簇头
	{
		node->ClearRsuId();
		Ptr<Packet> pkt = Create<Packet>(size);
		ClusterTag clustertag(++cluster_seq,node->GetId());
		pkt->AddByteTag(clustertag);
		TxInfo info = TxInfo (channelNumber);
		Address broadcast = Mac48Address::GetBroadcast ();
	    bool res=sender->SendX (pkt,broadcast,Packet_Number,info);   //RSU单播给收到的探测帧发送确认包
		if(!res)
		 {
			NS_LOG_ERROR("send probe message failed");
       	}
	}
}
void
MultipleChannelsExperiment::Sendrusackmessage (Ptr<WaveNetDevice> sender, uint32_t channelNumber)
{
	Ptr<Node> node = sender->GetNode();
	uint32_t nodeid=node->GetId();
//	if((node->GetRsuFlag())&&(node->rsugetmessage()))
	if(node->GetRsuFlag())
	{
		Ptr<Packet> pkt = Create<Packet>(size);
		RsuAckTag rsuacktag=RsuAckTag(nodeid);
        pkt->AddByteTag(rsuacktag);
        std::vector<ClusterMs> clusterms=node->getClusterMessage();   //RSU获取记录的簇信息
        node->ClearClusterMessage();
        std::vector<ClusterMs>::iterator i;
        TxInfo info = TxInfo (channelNumber);
     	Address broadcast = Mac48Address::GetBroadcast ();
        	bool res=sender->SendX (pkt,broadcast,Packet_Number,info);   //RSU单播给收到的探测帧发送确认包
            if(!res)
            {
        		    NS_LOG_ERROR("send rsuack message failed");
        	}


	}
}
void
MultipleChannelsExperiment::Sendbusackmessage (Ptr<WaveNetDevice> sender, uint32_t channelNumber)
{
	    Ptr<Node> node = sender->GetNode();
		uint32_t nodeid=node->GetId();
		if((node->GetClusterHeader())&&(node->GetRelateRsuFlag()))     //如果BUS为收到rsu回应帧的bus
		{
			Ptr<Packet> pkt = Create<Packet>(size);
			uint32_t rsuid=node->GetRsuId();
			BusAckTag busacktag(rsuid,nodeid);
			pkt->AddByteTag(busacktag);
			TxInfo info = TxInfo (channelNumber);
			Address broadcast = Mac48Address::GetBroadcast ();
		    bool res=sender->SendX (pkt, broadcast, Packet_Number, info);
			if(!res)
		     {
				  NS_LOG_ERROR("send bus ack message failed");
			}
		}
}
void
MultipleChannelsExperiment::Sendclustermessage (Ptr<WaveNetDevice> sender, uint32_t channelNumber)
{
	    Ptr<Node> node = sender->GetNode();
		uint32_t nodeid=node->GetId();
		if((node->GetClusterHeader())&&(node->GetRelateRsuFlag()))     //如果BUS为收到rsu回应帧的bus
		{
			Ptr<Packet> pkt = Create<Packet>(size);
			uint32_t rsuid=node->GetRsuId();
			BusAckTag busacktag(rsuid,nodeid);
			pkt->AddByteTag(busacktag);
			TxInfo info = TxInfo (channelNumber);
			Address broadcast = Mac48Address::GetBroadcast ();
		    bool res=sender->SendX (pkt, broadcast, Packet_Number, info);
			if(!res)
		     {
				  NS_LOG_ERROR("send bus ack message failed");
			}
		}
}

void
MultipleChannelsExperiment::Createudp()
{
	//  NodeContainer::Iterator i;
	//  int count=0;
	//  for(i=wifinodes.Begin();i!=wifinodes.End();i++)
	//  {
	  Ptr<MyApp> app = CreateObject<MyApp> ();
	  Ptr<MyApp> app2 = CreateObject<MyApp> ();
	  Ptr<Node> node1= wifinodes.Get(0);
	  Ptr<Node> node2= wifinodes.Get(1);
//	  uint32_t nodeid=(*i)->GetId();
	//  if(nodeid<10)   //如果为普通车辆及簇头节点,只有一个ip地址则
	//  {
	//  app->Setup (node,InetSocketAddress (Ipv4Address::GetBroadcast(), 8085),InetSocketAddress (wifiInterfaces.GetAddress(nodeid),49153),1500,5, DataRate ("1Mbps"));
	  app->Setup (node1,InetSocketAddress (wifiInterfaces.GetAddress(0),8085),InetSocketAddress (wifiInterfaces.GetAddress(1),49153),1500,5, DataRate ("1Mbps"));
	  app2->Setup (node2,InetSocketAddress (wifiInterfaces.GetAddress(1),8080),InetSocketAddress (wifiInterfaces.GetAddress(0),49153),1500,5, DataRate ("1Mbps"));
  //    std::cout << nodeid << "\t" << wifiInterfaces.GetAddress(count) << std::endl;
 //     count++;
//		  std::cout << wifiInterfaces.GetN() << std::endl;
//		  std::cout << wifinodes.GetN();
//	  }
	/*  if(nodeid >=22 && nodeid <= 31)
	  {
	  app->Setup (*i,InetSocketAddress (Ipv4Address::GetBroadcast(), 8085),InetSocketAddress (wifiInterfaces.GetAddress(nodeid), 49153), 1040, 5, DataRate ("1Mbps"));
	  } */
	  node1->AddApplication (app);
	  app->SetStartTime (Seconds (0));
	  app->SetStopTime (Seconds (10));
	  node2->AddApplication (app2);
	  app2->SetStartTime (Seconds (0));
	  app2->SetStopTime (Seconds (10));
 //    }
 //   }
}
void
MultipleChannelsExperiment::InstallApplication(void)
{
  NS_LOG_FUNCTION (this);
  double avg = 0.05/max_timeslot;
  NetDeviceContainer::Iterator i;
  for (i = devices_wave.Begin (); i != devices_wave.End (); ++i)    //普通车辆发包，rsu不能发包
    {
      Ptr<WaveNetDevice> sender = DynamicCast<WaveNetDevice> (*i);
      SchInfo schInfo = SchInfo (SCH1,false, EXTENDED_ALTERNATING);
      Simulator::Schedule (Seconds (0.0),&WaveNetDevice::StartSch,sender,schInfo);
      Ptr<ChannelCoordinator> coordinator = sender->GetChannelCoordinator ();
      for (uint32_t time = 0; time != simulationTime; ++time)
        {
          for (uint32_t sends = 0; sends != freq; ++sends)
            {
                  float i=sends*0.1;
				  Time sm=Seconds (rng->GetValue(time+i, time+i+0.015));//所有车辆节点广播,让公交车用以计算移动相似性值
				  Time chem=Seconds(rng->GetValue(time+i+0.015, time+i+0.020));//公交车收到信息后，计算自己的移动相似性值，并广播出去
				  Time bm=Seconds(rng->GetValue(time+i+0.020,time+i+0.025));//公交车确定簇头后，簇头广播自身消息
				  Time rm=Seconds(rng->GetValue(time+i+0.025, time+i+0.04));//普通车辆根据收到的簇头信息和入簇规则，加入簇
				  Time am=Seconds (rng->GetValue (time+i+0.040, time+i+0.050));//簇头广播发送时隙表
				  //第二个100ms
				  Time probemessage=Seconds (rng->GetValue (time+i+0.1, time+i+0.1+0.015));
				  Time rusackmessage=Seconds (rng->GetValue (time+i+0.1+0.015, time+i+0.1+0.030));
				  Time busackmessage=Seconds (rng->GetValue (time+i+0.1+0.030, time+i+0.1+0.045));
		//		  Time sendclustermessage=Seconds (rng->GetValue (time+i+0.1+0.045, time+i+0.1+0.060));   //关联结束后开始发送信息
	//			  Time sendclustermessage=Seconds (rng->GetValue (time+i+0.1+0.060, time+i+0.1+0.065));
     			  if (coordinator->IsCchInterval (sm))
				 {
				  Simulator::Schedule (sm, &MultipleChannelsExperiment::SendSm, this, sender, CCH);
				 }
				  if(coordinator->IsCchInterval(chem))
				  {
					Simulator::Schedule(chem,&MultipleChannelsExperiment::SendChem,this,sender,CCH,1);
				  }
				  if(coordinator->IsCchInterval(bm))
				  {
					  Simulator::Schedule(bm,&MultipleChannelsExperiment::SendBm,this,sender,CCH,1);
				  }
				  if(coordinator->IsCchInterval(rm))
				  {
					  Simulator::Schedule(rm,&MultipleChannelsExperiment::SendRm,this,sender,CCH);
				  }
		          if(coordinator->IsCchInterval (am))
			     {
				  Simulator::Schedule(am, &MultipleChannelsExperiment::SendAm, this, sender, CCH);
			     }
			     for(uint32_t j = 0;j != max_timeslot;j++)
				{
				  Time schSendTime=Seconds (rng->GetValue (time+i+0.050+(j*avg), time+i+0.050+(j+1)*avg));
				  if(coordinator->IsSchInterval(schSendTime))
				   {
					 Simulator::Schedule(schSendTime, &MultipleChannelsExperiment::SendSch, this, sender,j);
				   }
			    }
		          if(coordinator->IsCchInterval (probemessage))
			     {
			    	 Simulator::Schedule(probemessage, &MultipleChannelsExperiment::Sendprobemessage, this, sender, CCH);
			     }
			         if(coordinator->IsCchInterval (rusackmessage))
			     {
			     	 Simulator::Schedule(rusackmessage, &MultipleChannelsExperiment::Sendrusackmessage, this, sender, CCH);
			     }
			         if(coordinator->IsCchInterval (busackmessage))
			     {
			    	 Simulator::Schedule(busackmessage, &MultipleChannelsExperiment::Sendbusackmessage, this, sender, CCH);
			     }
		/*	     if(coordinator->IsCchInterval (sendclustermessage))
			     {
			       	 Simulator::Schedule(sendclustermessage, &MultipleChannelsExperiment::Sendclustermessage2, this, sender, CCH);
			     }  */
        }
   }
 }
}
void
MultipleChannelsExperiment::Run (void)
{
  NS_LOG_FUNCTION (this);
  {
    NS_LOG_DEBUG ("configuration :");
    {
    for (uint32_t r = 0; r != run; r++)
    {
    	//分别设置了随机数种子和运行次数。通常产生随机数的方法是：固定随机种子，改变运行次数。
    	RngSeedManager::SetSeed (1);
    	RngSeedManager::SetRun (17+r);
    	InitStatus ();
    	CreateNodes ();
    	CreateDevice();
    	CreateWaveDevice ();
    	SetupMobility ();
  //  	Createudp();
    	InstallApplication();

    	Simulator::Stop (Seconds (simulationTime));
    	AnimationInterface anim ("bus20.xml");
        phy.EnablePcap ("bus21", staDevices.Get (0),true);
        phy.EnablePcap ("bus21", staDevices.Get (1),true);
        anim.EnablePacketMetadata (true);
    	Simulator::Run ();
    	 in.open(filename,std::ios::app);
    	 in<<"send packet:"<<send_number<<" receive packet:"<<receive_number<<" time delay:"<<sumdelay<<std::endl;
    	 in.close();
    	 std::cout<<"send packet:"<<send_number<<" receive packet:"<<receive_number<<" time delay:"<<sumdelay<<std::endl;
    	 std::cout<<sum_change_head<<std::endl;
    	 Simulator::Destroy ();
    }
    }
  }
  }

void
MultipleChannelsExperiment::InitStatus (void)
{
  // used for sending packets randomly
 rng = CreateObject<UniformRandomVariable> ();
 rng->SetStream (1);

  std::map<uint32_t, std::vector<uint32_t> *>::iterator i;
  for (i = broadcastPackets.begin(); i != broadcastPackets.end();++i)
  {
	  i->second->clear();
	  delete i->second;
	  i->second = 0;
  }
  broadcastPackets.clear();
  receivedPackets.clear();
  sends = SendStat ();
  sequence = 0;
  cluster_seq = 0;
  receives = 0;
  queues = 0;
  delaySum = 0;
  receiveSum = 0;

 // Simulator::ScheduleDestroy (&MultipleChannelsExperiment::StatQueuedPackets, this);
}
void
MultipleChannelsExperiment::Stats (uint32_t randomNumber)
{
  NS_LOG_FUNCTION (this);
  NS_ASSERT (receives != 0);
  // first show stats records.
  NS_LOG_DEBUG (" simulation result:(run number = " << randomNumber << ")");
  NS_LOG_DEBUG (" nodes = " << nodesNum);
  NS_LOG_DEBUG (" simulation time = " << simulationTime << "s");
  NS_LOG_DEBUG (" send packets = " << sequence);
  NS_LOG_DEBUG (" receives packets = " << receives);
  NS_LOG_DEBUG (" queues packets = " << queues);
  NS_LOG_DEBUG (" lost packets = " << (sequence - queues - receives));
  NS_LOG_DEBUG (" the sum delay of all received packets = " << delaySum << "micros");

  if (broadcast)
	NS_LOG_UNCOND (" the partly received broadcast packets = " << broadcastPackets.size ());

  // second show performance result
  // stats PDR (packet delivery ratio)
  double PDR = receives / (double)(sequence - queues);
  // stats average delay
  double AverageDelay = delaySum / receiveSum / 1000.0;
  // stats system throughput, Mbps
  double Throughput = receives * size * 8 / simulationTime / 1000.0 / 1000.0;
  // stats average throughput, kbps
  double AverageThroughput = Throughput / (double)nodesNum * 1000;

  NS_LOG_DEBUG (" PDR = " << PDR);
  NS_LOG_DEBUG (" AverageDelay = " << AverageDelay << "ms");
  NS_LOG_DEBUG (" Throughput = " << Throughput << "Mbps");
  NS_LOG_DEBUG (" AverageThroughput = " << AverageThroughput << "Kbps");

  pdr+=PDR;
  delay+=AverageDelay;
  system_throughput+=Throughput;
  average_throughput+=AverageThroughput;
}

int
main (int argc, char *argv[])
 {
 LogComponentEnable ("WaveMultipleChannelTest", LOG_DEBUG);//开启类的Log组件，并设置log级别为LOG_DEBUG
 MultipleChannelsExperiment experiment;
  if (experiment.Configure (argc, argv))
    {
      experiment.Run ();
    }
  return 0;
}
